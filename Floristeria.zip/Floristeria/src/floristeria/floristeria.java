package floristeria;

public class floristeria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa isaCasa= new Casa("Blanca con rosado",3,4,true,true);
		System.out.println(isaCasa.describir());
	}

}
