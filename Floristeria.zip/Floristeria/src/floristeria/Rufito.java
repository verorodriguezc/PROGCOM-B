package floristeria;

public class Rufito {

}
